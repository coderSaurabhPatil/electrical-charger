package ampower;
use Mojo::Base 'Mojolicious', -signatures;
use DBD::mysql;
use Mojo::mysql;
use DBI;


# This method will run once at server start
sub startup ($self) {

    # Load configuration from config file
    my $config = $self->plugin('NotYAMLConfig');

    # Configure the application
    $self->secrets($config->{secrets});

my $db_name = 'ampower';
my $db_host = 'localhost';
my $db_port = '3306';
my $db_user = 'quantumd';
my $db_pass = 'Quantumd%40123'; 

    my $mysql = Mojo::mysql->new("mysql://$db_user:$db_pass\@$db_host/$db_name");



  $self->helper(mysql => sub { return $mysql });




  # Router
  my $r = $self->routes;

  # Normal route to controller



  $r->get('/')->to('Login#login');
  
  $r->post('/login')->to('Login#validUserCheck');

  $r->get('/logout')->to('Login#login');

  $r->get('/signupfrom')->to('Signup#signup_form');


#---------------------------------------------------------------- ---------- ---------------------------------------------------------------
  
  
$r->get('/stations')->to('map#stations');

$r->get('/user_info')->to("UserInfo#user_info");



$r->get('/chargingsessions')->to('chargingsessions#chargingsessions');

$r->post('/search-session')->to('session#search_sesion');


$r->get('/charging_status')->to('charging_status#status');

$r->post('/charge_info')->to('ChargeInfo#show_charge_info');

$r->get('/charging_details')->to('ChargingDetails#charging_details');

$r->get('/charging_dt')->to('ChargingDetails#charging_status');

$r->get('/show_charging_details')->to('ChargingDetails2#show_charging_details');



$r->get('/charging')->to('charging#charging');

$r->post('/start_charging')->to('startcharging#updateUserEVSEAction');

$r->post('/stop_charging')->to('StopCharging#updateUserEVSEAction');


$r->get('/bill')->to('bill#bill');

$r->get('/bill1')->to('bill1#bill');


$r->get('/book')->to('book#book');


$r->get('/bookev')->to('book#bookev');

$r->get('/search')->to('book#search');

$r->get('/search_bar')->to('book#search_bar');

$r->get('/ev_display')->to('book#ev_display');

$r->get('/submit_booking')->to('book#SubmitBookingFormData');



}

1;
