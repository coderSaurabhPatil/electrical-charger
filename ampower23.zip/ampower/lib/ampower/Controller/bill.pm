package ampower::Controller::Bill;
use Mojo::Base 'Mojolicious::Controller';
use PDF::WebKit;
use Data::Dumper;


sub bill {
    my $self = shift;
    $self->check_login;

    my ($totalBillingAmount, $GstForTotal, $finalBill); 
    my $db = $self->app->mysql->db;

    # Build the SQL query
    my $sql = "SELECT * FROM evse WHERE id=1";

    $db->query('SELECT * FROM evse WHERE id = ?', 1, sub {
        my ($db, $err, $evse_results) = @_;

        if ($err) {
            $self->render(text => "Database error: $err", status => 500);
            return;
        }

        # Fetch tariff information data from the database
        $db->query('SELECT * FROM tariffInfo WHERE evse_id = ?', 1, sub {
            my ($db, $err, $tariff_results) = @_;

            if ($err) {
                $self->render(text => "Database error: $err", status => 500);
                return;
            }

            # Fetch charging session data from the database
            $db->query('SELECT * FROM charging_sessions WHERE evse = ?', 1, sub {
                my ($db, $err, $charging_results) = @_;

                if ($err) {
                    $self->render(text => "Database error: $err", status => 500);
                    return;
                }

                $self->mysql->db->query('SELECT minConnChrgs FROM tariffInfo WHERE evse_id = ?', 1, sub {
                    my ($db, $err, $result) = @_;
                    if ($err) {
                        say "Database error: $err";
                        return;
                    }
                    my $parkingCharge = $result->hash->{minConnChrgs};
                    say "Parking charge: $parkingCharge";
                    

                    # Fetching total per kWh charges
                    $self->mysql->db->query('SELECT perKWhChrgs FROM tariffInfo WHERE evse_id = ?', 1, sub {
                        my ($db, $err, $result) = @_;
                        if ($err) {
                            say "Database error: $err";
                            return;
                        }
                        my $perKWhCharge = $result->hash->{perKWhChrgs};
                        say "Per kWh charge: $perKWhCharge";

                        # Fetching total unit consumed
                        $self->mysql->db->query('SELECT unit_consumed FROM charging_sessions WHERE evse = ?', 1, sub {
                            my ($db, $err, $result) = @_;
                            if ($err) {
                                say "Database error: $err";
                                return;
                            }
                            my $unitConsumed = $result->hash->{unit_consumed};
                            say "Total unit consumed: $unitConsumed";

                            # Calculating total per kWh charges
                            my $totalPerKWhCharges = $perKWhCharge * $unitConsumed;
                            say "Total per kWh charges: $totalPerKWhCharges";

                            # Fetching total per minute charges
                            $self->mysql->db->query('SELECT perMinChrgs FROM tariffInfo WHERE evse_id = ?', 1, sub {
                                my ($db, $err, $result) = @_;
                                if ($err) {
                                    say "Database error: $err";
                                    return;
                                }
                                my $perMinChrgs = $result->hash->{perMinChrgs};
                                say "Per minute charge: $perMinChrgs";

                                # Fetching total time charged
                                $self->mysql->db->query('SELECT time_charged FROM charging_sessions WHERE evse = ?', 1, sub {
                                    my ($db, $err, $result) = @_;
                                    if ($err) {
                                        say "Database error: $err";
                                        return;
                                    }
                                    my $time_charged_seconds = $result->hash->{time_charged};
                                    
                                   
                                    # Convert seconds to minutes
                                    my $time_charged_minutes = int($time_charged_seconds / 60);
                                    say "Total time charged: $time_charged_minutes minutes";

                                    my $totalParkingcharges = $parkingCharge * $time_charged_minutes;
                                    say "Total parking charges: $totalParkingcharges";
                                    # Calculating total per minute charges
                                    my $totalPerMinuteCharges = $perMinChrgs * $time_charged_minutes;
                                    say "Total per minute charges: $totalPerMinuteCharges";

                                    # Calculating total billing amount
                                    my $totalBillingAmount = $totalParkingcharges + $totalPerKWhCharges + $totalPerMinuteCharges;
                                    say "Total billing amount: $totalBillingAmount";

                                    my $GstForTotal=$totalBillingAmount*0.18;
                                    say "Gst amont on total: $GstForTotal";

                                    my $finalBill = $totalBillingAmount + $GstForTotal;
                                    say "Final amount of bill is : $finalBill ";

                                    # Stash the calculated values
                                    $self->stash(
                                        totalBillingAmount => $totalBillingAmount,
                                        GstForTotal        => $GstForTotal,
                                        finalBill          => $finalBill
                                    );
say "Stashed totalBillingAmount: $totalBillingAmount";
say "Stashed GstForTotal: $GstForTotal";
say "Stashed finalBill: $finalBill";
                                    $self->render(
                                        template     => 'myTemplates/bill',
                                        evse_data    => $evse_results->hashes,
                                        tariff_data  => $tariff_results->hashes,
                                        charging_data => $charging_results->hashes,
                                    );
                                });
                            });
                        });
                    });
                });

            });
        });
    });
}



sub download_pdf {
    my $self = shift;

    # Declare variables to hold billing information
    my ($totalBillingAmount, $GstForTotal, $finalBill);

    # Retrieve data from the evse table
    my $evse_data = $self->mysql->db->query('SELECT * FROM evse WHERE id=1')->hashes->to_array;

    # Retrieve data from the tariffInfo table
    my $tariff_data = $self->mysql->db->query('SELECT * FROM tariffInfo WHERE evse_id = ?', 1)->hashes->to_array;

    # Retrieve data from the charging_sessions table
    my $charging_data = $self->mysql->db->query('SELECT * FROM charging_sessions WHERE evse = ?', 1)->hashes->to_array;

    # Fetching parking charge
    $self->mysql->db->query('SELECT minConnChrgs FROM tariffInfo WHERE evse_id = ?', 1, sub {
        my ($db, $err, $result) = @_;
        if ($err) {
            say "Database error: $err";
            return;
        }
        my $parkingCharge = $result->hash->{minConnChrgs};
        say "Parking charge: $parkingCharge";

        # Fetching per kWh charge
        $self->mysql->db->query('SELECT perKWhChrgs FROM tariffInfo WHERE evse_id = ?', 1, sub {
            my ($db, $err, $result) = @_;
            if ($err) {
                say "Database error: $err";
                return;
            }
            my $perKWhCharge = $result->hash->{perKWhChrgs};
            say "Per kWh charge: $perKWhCharge";

            # Fetching total unit consumed
            $self->mysql->db->query('SELECT unit_consumed FROM charging_sessions WHERE evse = ?', 1, sub {
                my ($db, $err, $result) = @_;
                if ($err) {
                    say "Database error: $err";
                    return;
                }
                my $unitConsumed = $result->hash->{unit_consumed};
                say "Total unit consumed: $unitConsumed";

                # Calculate total per kWh charges
                my $totalPerKWhCharges = $perKWhCharge * $unitConsumed;
                say "Total per kWh charges: $totalPerKWhCharges";

                # Fetching per minute charge
                $self->mysql->db->query('SELECT perMinChrgs FROM tariffInfo WHERE evse_id = ?', 1, sub {
                    my ($db, $err, $result) = @_;
                    if ($err) {
                        say "Database error: $err";
                        return;
                    }
                    my $perMinChrgs = $result->hash->{perMinChrgs};
                    say "Per minute charge: $perMinChrgs";

                    # Fetching total time charged
                    $self->mysql->db->query('SELECT time_charged FROM charging_sessions WHERE evse = ?', 1, sub {
                        my ($db, $err, $result) = @_;
                        if ($err) {
                            say "Database error: $err";
                            return;
                        }
                        my $time_charged_seconds = $result->hash->{time_charged};

                        # Convert seconds to minutes
                        my $time_charged_minutes = int($time_charged_seconds / 60);
                        say "Total time charged: $time_charged_minutes minutes";

                        my $totalParkingcharges = $parkingCharge * $time_charged_minutes;
                        say "Total parking charges: $totalParkingcharges";

                        # Calculate total per minute charges
                        my $totalPerMinuteCharges = $perMinChrgs * $time_charged_minutes;
                        say "Total per minute charges: $totalPerMinuteCharges";

                        # Calculate total billing amount
                        $totalBillingAmount = $totalParkingcharges + $totalPerKWhCharges + $totalPerMinuteCharges;
                        say "Total billing amount: $totalBillingAmount";

                        $GstForTotal = $totalBillingAmount * 0.18;
                        say "Gst amount on total: $GstForTotal";

                        $finalBill = $totalBillingAmount + $GstForTotal;
                        say "Final amount of bill is : $finalBill ";

                        # Generate HTML content
                       # Initialize HTML content
my $html_content = <<'HTML';
<html>
<head>
<title>Fetched Data PDF</title>
<style>
table {
width: 100%;
border-collapse: collapse;
}
th, td {
border: 1px solid black;
padding: 8px;
text-align: left;
}
th {
background-color: #f2f2f2;
}

.page-border {
border: 1px solid black;
padding: 20px; /* Add padding for better spacing */
}

</style>
</head>
<body>
<!-- <div class="page-border"> --> <!-- Add border to this div -->

<div class="container topspace chdetail">
<h1 class="heading3 text-center text-uppercase" align="center">Billing Information</h1>
<div class="row mt-5">
<div class="col-md-12">
<div class="bill-info">
<table class="table table-bordered text-center">
<tr>
<th>Charger Type</th>
<th>Charger Id</th>
<th>Charges</th>
</tr>
HTML

foreach my $evse (@$evse_data) {
$html_content .= <<"HTML";
<tr>
<td>$evse->{chargerType}</td>
<td>$evse->{code}</td>
<td>
HTML

foreach my $tariff (@$tariff_data) {
$html_content .= <<"HTML";
<p>Parking Rs.: $tariff->{minConnChrgs}/m</p>
<p>kWh Rs.: $tariff->{perKWhChrgs} /m</p>
<p>Minute Rs.: $tariff->{perMinChrgs}</p>
HTML
}

$html_content .= <<"HTML";
</td>
</tr>
HTML
}

# Complete the HTML content
$html_content .= <<"HTML";
</table><br><br> 
</div>

HTML

$html_content .= <<"HTML";
<table class="table table-bordered text-center">
<tbody>
HTML

foreach my $charging (@$charging_data) {

my $time_charged = sprintf("%02d:%02d:%02d", int($charging->{time_charged} / 3600), int(($charging->{time_charged} % 3600) / 60), int($charging->{time_charged} % 60));

$html_content .= <<"HTML";

<h1 class="heading3 text-center text-uppercase" align="center">Billing Details</h1>
<th>Charging Parameter</th>
<th>Time</th>
</tr>
<tr>
<td>Charging Value</td>
<td>1 Mins</td>
</tr>
<tr>
<tr>
<td>Total Units Consumed (kWH)</td>
<td>$charging->{unit_consumed}</td>
</tr>
<tr>
<td>Total Charging Time (HH:MM:SS)</td>
<td>$time_charged</td>
</tr>

<tr>
<td>Sub Total</td>
<td>Rs.$totalBillingAmount/-</td>
</tr>
<tr>
<td>GST 18%</td>
<td>Rs. $GstForTotal/-</td>
</tr>
<tr>
<td>Total Amount</td>
<td>Rs. $finalBill/-</td>
</tr>
HTML
}

$html_content .= <<"HTML";
</tbody>
</table>
HTML


$html_content .= <<"HTML";
</div>
</div>
</div>
</body>
</html>
HTML
                        # Continue generating HTML content with calculated values

                        # Generate PDF content
                        my $pdf = PDF::WebKit->new(\$html_content);
                        my $pdf_content = $pdf->to_pdf;

                        my $filename = 'bill.pdf';

                        # Set the response headers for PDF download
                        $self->res->headers->content_type('application/pdf');
                        $self->res->headers->content_disposition("attachment; filename=\"$filename\"");

                        # Render the PDF content
                        $self->render(data => $pdf_content);
                    });
                });
            });
        });
    });
}


sub check_login {
    my ($self) = @_;

    if ($self->session('is_auth')) {
        say "User is logged in";
        return 1;  # User is authenticated
    } else {
        say "User is not logged in";
        $self->redirect_to('/');  # Redirect to the login page
        return 0;  # User is not authenticated
    }
}



1;

