package ampower::Controller::ChargingDetails;
use Mojo::Base 'Mojolicious::Controller', -signatures;
use Mojo::Log;

sub charging_details ($self) {
    my $station_id = $self->param('station_id'); # Get the parameter "station_id"

    say "id : $station_id";

    $self->session(station_id => $station_id);

    # Render the template
    $self->render(template => 'myTemplates/charging-details');
}

1;
