package ampower::Controller::Signup;

use Mojo::Base 'Mojolicious::Controller', -signatures;
use Mojo::mysql;

sub signup_form ($self) {
    # Access the PostgreSQL database handle
    my $mysql = $self->app->mysql->db;
    
    # Perform a database query to retrieve all users
    my $all_users = $mysql->query('SELECT * FROM users')->hashes->to_array;

    # Render the template "signup_form.html.ep" with the retrieved user data
    $self->render(template => 'myTemplates/signup-form', all_users => $all_users);
}


sub process_signup {
    my $self = shift;
    my $fname = $self->param('fname');
    my $email = $self->param('email');
    my $mobile = $self->param('mobile');
    my $pincode = $self->param('pincode');
    my $status = $self->param('status');
    my $gstin_no = $self->param('gstin_no');
    my $usertype = $self->param('usertype');

    my $deletedon = $self->param('deletedon');
    my $razorpay_cust_id = $self->param('razorpay_cust_id');
    my $razorpay_response = $self->param('razorpay_response');
    my $bankaccname = $self->param('bankaccname');
    my $bankaccnumber = $self->param('bankaccnumber');
    my $bankname = $self->param('bankname');
    my $bankifsc = $self->param('bankifsc');
    my $fund_account_id = $self->param('fund_account_id');
    my $rfid = $self->param('rfid');

    # Generate the password
    my $password = generate_password($fname);

    $self->check_email_exist($email, sub {
        my ($self, $exists) = @_;

        if ($exists) {
            $self->flash(error => 'User already exists');
            $self->render(template => 'myTemplates/signup_form'); 
        } else {
            $self->mysql->db->insert('users',
                {
                    fname   => $fname,
                    email    => $email,
                    password => $password,  
                    mobile   => $mobile,
                    pincode  => $pincode,
                    status   => $status,
                    gstin_no  => $gstin_no,
                    usertype  => $usertype,
                    deletedon => $deletedon,
                    razorpay_cust_id => $razorpay_cust_id,
                    razorpay_response => $razorpay_response,
                    bankaccname => $bankaccname,
                    bankaccnumber => $bankaccnumber,
                    bankname => $bankname,
                    bankifsc => $bankifsc,
                    fund_account_id => $fund_account_id,
                    rfid => $rfid
                },
                sub {
                    my ($db, $err, $result) = @_;
                    if ($err) {
                        return $self->render(json => {error => "Database error: $err"});
               }
                #     } else {
                #         $self->flash(error => 'User registered successfully...');
                #         $self->render(template => 'myTemplates/login');                 
                #    }
                }
            );
        }
    });
}
sub forget_password {
    my $self = shift;
    $self->render(template => 'myTemplates/forgot-password');
}

sub send_email_with_password {
    my $self = shift;

    # Retrieve email details from the registration form or parameters
    my $to      = $self->param('to');  # Assuming 'to' is the name of the email input field in the registration form
    my $subject = 'Registration Success - Your New Password';
    
    # Generate a password
    my $password = generate_password();

    # Email body with the generated password
    my $body = "Congratulations! You have successfully registered. Your new password is: $password";

    # Create the email object
    my $email = Mojo::Email->new;
    $email->from('your_email@example.com');
    $email->to($to);
    $email->subject($subject);
    $email->body($body);

    # Send the email
    if ($email->send) {
        $self->render(text => 'Registration Success! Check your email for your new password');
    } else {
        $self->render(text => 'Failed to send email');
    }
}

sub generate_password {
    my ($fname) = @_;

    # Extract the first three letters of the username
    my $first_three_letters = substr($fname, 0, 3);

    # Generate a random 3-digit number
    my $random_number = int(rand(900)) + 100;

    # Choose a random special character
    my @special_characters = qw( @ );
    my $special_character = $special_characters[int(rand(scalar @special_characters))];

    # Concatenate the components to form the password
    my $password = $first_three_letters . $special_character . $random_number;

    return $password;
}

sub check_email_exist {
    my ($self, $email, $callback) = @_;

    # Access the PostgreSQL database handle
    my $mysql = $self->app->mysql->db;

    # Prepare the SQL statement
    my $sql = 'SELECT COUNT(*) AS count FROM users WHERE email = ?';

    # Execute the query
    $mysql->query($sql, $email, sub {
        my ($db, $err, $results) = @_;
        if ($err) {
            # Handle database error
            $self->render(json => {error => "Database error: $err"});
            return;
        }
        my $count = $results->hash->{count};
        $callback->($self, $count > 0 ? 1 : 0);
    });
}


1;
