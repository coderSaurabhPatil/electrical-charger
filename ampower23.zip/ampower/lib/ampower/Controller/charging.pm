package ampower::Controller::Charging;

use Mojo::Base 'Mojolicious::Controller', -signatures;

# Mojolicious Controller

# Mojolicious Controller

sub charging {
    my $c = shift;


    # Render the dashboard template
    $c->render(template => 'myTemplates/charging');
}
1;
