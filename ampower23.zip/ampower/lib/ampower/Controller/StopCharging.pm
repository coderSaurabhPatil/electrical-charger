package ampower::Controller::StopCharging;

use Mojo::Base 'Mojolicious::Controller', -signatures;



sub updateUserEVSEAction {

    
 my $c = shift;

    # Retrieve the JSON payload sent in the request body
    my $payload = $c->req->json;

    my $userid = $c->session('username');
    say "username :$userid";


    # Extract the values from the payload
    my $minConnChrgs   = $payload->{minConnChrgs};
    my $perKWhChrgs    = $payload->{perKWhChrgs};
    my $perMinChrgs    = $payload->{perMinChrgs};
    my $imei           = $payload->{imei};

    my $EVSE_ID        = $payload->{EVSE_ID};
    my $vehid          = $payload->{vehid};
    my $status         = $payload->{status};
  
    my $CALL_REQUEST   = $payload->{CALL_REQUEST};
   
    my $localDateTime = localtime();

    # Print the extracted values
    say "minConnChrgs123: $minConnChrgs";
    say "perKWhChrgs: $perKWhChrgs";
    say "perMinChrgs: $perMinChrgs";
    say "imei: $imei";
    
    say "EVSE_ID: $EVSE_ID";
    say "vehid: $vehid";
    say "status: $status";
 
    say "CALL_REQUEST: $CALL_REQUEST";



   my $username_from = $c->mysql->db->query('select fname,id  from users where email =?',$userid)->hash;

   my $username_fromDB = ($username_from ->{fname});
   my $user_id = ($username_from -> {id});

   say "usrname_fromDB :  $username_fromDB";
   say "User ID is : $user_id ";
  


 

  

     my $code_fromDB = $vehid;

     say "Code is $code_fromDB";


   
    my $check_query = $c->mysql->db->query('select srid,createdon from evuserEVSEAction WHERE evuserid= ? AND evseid=? AND createdon > DATE_SUB(NOW(), INTERVAL 9 HOUR) AND deletedOn IS NULL ORDER BY createdon DESC LIMIT 1',$user_id,$EVSE_ID)->hash;
    my $srid  = ($check_query->{srid});
    my $createdon = ($check_query->{createdon});
    say  "Created on is $createdon";
    
    if($status =~ /^STOP$/) {



   my $query = $c->mysql->db->query("select id, stopped_at, stopped_reason, transaction_id from charging_sessions where evse = ?  AND charging_state='Charging' ORDER BY started_at DESC LIMIT 1", $user_id)->hash;


# my $query = $c->mysql->db->query("select id, stopped_at, stopped_reason, transaction_id from charging_sessions where evse = ? AND status = 'Accepted' AND charging_state='Charging' AND started_at >= ? ORDER BY started_at DESC LIMIT 1", $user_id, $createdon)->hash;
    
    my $charging_session_id = ($query->{id});
    say "charging_session_id :$charging_session_id ";



   my $stopped_at =($query->{stopped_at}) ;
   say "Stopped at : $stopped_at";
   my $stopped_reason = ($query->{stopped_reason});
   say "Reason for stopping the charging session : $stopped_reason";

 
    # UPDATE THE CHARGING SESSION RECORD.....stopped_at|stopped_reason
my $updateChargingSessionQuery = $c->mysql->db->query("UPDATE charging_sessions SET stopped_at = now(), stopped_reason = 'Ended' WHERE evse = ? AND id = ? AND stopped_reason != ''", $EVSE_ID, $charging_session_id);

     
    
    # CHARGING SESSION COMPLETED...
    my $delQuery_Rws = $c->mysql->db->query('update evuserEVSEAction set deletedOn=now() WHERE srid=?',$srid );
    
   
    
        if($delQuery_Rws){

    open(FH_4, ">", "public/START_STOP_LOGS/${user_id}_${EVSE_ID}_stop_pkt.txt") or die "File couldn't be opened";
    print FH_4 "$CALL_REQUEST";
    close(FH_4);

    open(FH_5, ">>", "public/START_STOP_LOGS/stoppktLogs.txt") or die "File couldn't be opened";
    print FH_5 "\n Username is => $username_fromDB, Charger is => $code_fromDB, Stop packet sent to Main Program After DB Insertion is => $CALL_REQUEST, Server Time is => $localDateTime \n";
    print FH_5 "--------------------------------------------------------------------------------------------------------------------------------------------";
    close(FH_5);
    }


    }

     
}
    

    










1;




 