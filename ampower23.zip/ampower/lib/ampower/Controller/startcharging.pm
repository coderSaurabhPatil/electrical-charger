package ampower::Controller::Startcharging;

use Mojo::Base 'Mojolicious::Controller', -signatures;


sub updateUserEVSEAction {

    
 my $c = shift;

    # Retrieve the JSON payload sent in the request body
    my $payload = $c->req->json;

    my $userid = $c->session('username');
    say "username :$userid";


    # Extract the values from the payload
    my $minConnChrgs   = $payload->{minConnChrgs};
    my $perKWhChrgs    = $payload->{perKWhChrgs};
    my $perMinChrgs    = $payload->{perMinChrgs};
    my $imei           = $payload->{imei};

    my $EVSE_ID        = $payload->{EVSE_ID};
    my $vehid          = $payload->{vehid};
    my $status         = $payload->{status};
    my $CHARGING_OPTION= $payload->{CHARGING_OPTION};
    my $CALL_REQUEST   = $payload->{CALL_REQUEST};
    my $CHARGING_VALUE = $payload->{CHARGING_VALUE};
    my $localDateTime = localtime();

    # Print the extracted values
    say "minConnChrgs123: $minConnChrgs";
    say "perKWhChrgs: $perKWhChrgs";
    say "perMinChrgs: $perMinChrgs";
    say "imei: $imei";
    
    say "EVSE_ID: $EVSE_ID";
    say "vehid: $vehid";
    say "status: $status";
    say "CHARGING_OPTION: $CHARGING_OPTION";
    say "CALL_REQUEST: $CALL_REQUEST";
    say "CHARGING_VALUE: $CHARGING_VALUE";


   my $username_from = $c->mysql->db->query('select fname,id  from users where email =?',$userid)->hash;

   my $username_fromDB = ($username_from ->{fname});
   my $user_id = ($username_from -> {id});

   say "usrname_fromDB :  $username_fromDB";
   say "User ID is : $user_id ";
  


 

  

     my $code_fromDB = $vehid;

     say "Code is $code_fromDB";


   
    my $check_query = $c->mysql->db->query('select srid,createdon from evuserEVSEAction WHERE evuserid= ? AND evseid=? AND createdon > DATE_SUB(NOW(), INTERVAL 9 HOUR) AND deletedOn IS NULL ORDER BY createdon DESC LIMIT 1',$user_id,$EVSE_ID)->hash;
    my $srid  = ($check_query->{srid});
    my $createdon = ($check_query->{createdon});
    
    

    if ($status =~ /^START$/) {
        
    my $file_path = "public/START_STOP_LOGS/startpktLogs.txt";
    
    if (open(my $FH_1, ">>", $file_path)) {
        print $FH_1 "\nUsername is => $username_fromDB, Charger is => $code_fromDB, Start packet received from App is => $CALL_REQUEST , Server Time is => $localDateTime \n";
        close($FH_1);

    
     my $count_rows_created = $c->mysql->db->query('SELECT COUNT(*) as count FROM evuserEVSEAction WHERE chrgnTrnxId = 0 AND evuserid = ? AND evseid = ? AND createdon > DATE_SUB(NOW(), INTERVAL 2 SECOND)', $user_id, $EVSE_ID)->rows;

 # Initialize to 0


if ($count_rows_created) {
         my $rws = $c->mysql->db->query('INSERT INTO evuserEVSEAction SET evuserid = ?, evseid = ?, vehid = 1, chrgnOption = ?, chrgnValue = ?, sessionid = 1, sessionsrno = 1223, createdon = NOW()', $user_id, $EVSE_ID, $CHARGING_OPTION, $CHARGING_VALUE)->rows;

           say "rws :$rws";

           

  if ($rws == 1) {
        open(my $FH_2, ">", "public/START_STOP_LOGS/${user_id}_${EVSE_ID}_start_pkt.txt");
        print $FH_2 "$CALL_REQUEST"; # Assuming %EMB is defined somewhere
        close($FH_2);

        open(my $FH_3, ">>", $file_path);
        print $FH_3 "\n Username is => $username_fromDB, Charger is => $code_fromDB, Start packet sent to Main Program After DB Insertion is => $CALL_REQUEST, Server Time is => $localDateTime \n";
        print $FH_3 "------------------------------------------------------------------------------------------------------------------------------------------------";
        close($FH_3);

        return "SUCCESS";
    }


        else {
        open(my $FH_3, ">>", $file_path);
        print $FH_3 "\n Username is => $username_fromDB, Charger is => $code_fromDB, Start packet not sent to Main Program at Server Time => $localDateTime \n";
        print $FH_3 "------------------------------------------------------------------------------------------------------------------------------------------------";
        close($FH_3);

        return "FAILURE";
    }
    } else {
    # Pass error message to the template
    $c->stash(error_message => "File couldn't be opened");
}
}





}


}
1;