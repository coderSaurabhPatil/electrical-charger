


package ampower::Controller::Session;

use Mojo::Base 'Mojolicious::Controller', -signatures;
use Time::Piece; 
use Data::Dumper;

sub search_sesion {

   
   my $c = shift;

    # Retrieve JSON data from the request body
    my $request_body = $c->req->json;

    # Extract start date and end date in 'DD/MM/YYYY' format
    my $startDate = $request_body->{startDate};
    my $endDate   = $request_body->{endDate};

    # Parse the dates and format them to 'YY-MM-DD'
    my $formattedStartDate = Time::Piece->strptime($startDate, '%d/%m/%Y')->strftime('%Y-%m-%d');
    my $formattedEndDate   = Time::Piece->strptime($endDate, '%d/%m/%Y')->strftime('%Y-%m-%d');

    # Debug: Print the extracted and formatted start and end dates
    print "Start Date (YY-MM-DD): $formattedStartDate\n";
    print "End Date (YY-MM-DD): $formattedEndDate\n";
    
    # Retrieve user ID from the session
    my $user_id = $c->session('username');

    # Debug: Print the user ID
    print "User ID: $user_id\n";

    # Fetch EVSE information from the database based on the user ID
my $evse_info = $c->mysql->db->query('SELECT id FROM users WHERE email = ?', $user_id)->hash;

# Extract EVSE ID from the retrieved information
my $evse_id = $evse_info->{id};

# Debug: Print the fetched EVSE ID
print "EVSE ID: $evse_id\n";


 




# Retrieve data from the charging_sessions table
my $charging_sessions = $c->mysql->db->query(
    'SELECT ROUND(unit_consumed/1000, 3) AS unit_consumed,
       stopped_reason,
       SEC_TO_TIME(time_charged) AS time_charged,
       DATE(started_at) AS started_date
       FROM charging_sessions
       WHERE evse = ? AND DATE(started_at) = ?
       ORDER BY started_at ASC
       LIMIT 1',
    $evse_id,
    $formattedStartDate)->hashes->map(sub{
        return{
            unit_consumed => $_->{unit_consumed},
            stopped_reason => $_->{stopped_reason},
            time_charged   =>$_->{time_charged},
            started_date  =>$_->{started_date}


        };
    }
)->to_array;



my $evuserEVSEAction = $c->mysql->db->query("SELECT t1.srId,
       t1.evseid,
       CONCAT(t2.name, ' [', t2.code, ']') AS evseNameCode,
       CONCAT(t3.vehModel, ' (', t3.vehicleType, ')', '-', t3.vehRegNo) AS vehicleDetails,
       DATE_FORMAT(t1.createdOn, '%d-%b-%y %r') AS startDateTimeFormatted,
       DATE_FORMAT(t1.deletedOn, '%d-%b-%y %r') AS deletedOnStr,
       TIMEDIFF(t1.deletedOn, t1.createdOn) AS chargingDuration,
       t1.createdOn AS startDateTime,
       BillStatusRef
FROM evuserEVSEAction t1,
     evse t2,
     evehicles t3
WHERE t1.deletedOn IS NULL
AND t2.deletedOn IS NULL
AND t3.deletedOn IS NULL
AND t1.evseid = 1
AND t1.evseid = t2.id
AND DATE(t1.createdOn) BETWEEN ? AND ?
AND t1.vehid = t3.vehid
ORDER BY t1.createdon ASC", $evse_id, $formattedStartDate, $formattedEndDate)->hashes->map(sub{

    return{

        srId => $_->{srId},
        evseid => $_->{evseid},
        evseNameCode => $_->{evseNameCode},
        vehicleDetails => $_->{vehicleDetails},
      
        startDateTimeFormatted=>$_->{startDateTimeFormatted},
        deletedOnStr=>$_->{deletedOnStr}, 
        chargingDuration => $_->{chargingDuration},
        startDateTime=>$_->{startDateTime},
        BillStatusRef=>$_->{BillStatusRef}

    }

})->to_array;


my $customer_payout_cso_api_response = $c->mysql->db->query('select order_id, payment_id, transfer_id, transfer_amount/100 from 
customer_payout_cso_api_response WHERE transfer_id IS NOT NULL AND transfer_amount IS NOT NULL AND evuserEVSEActionId=1 LIMIT 1
',$evse_id)->hashes->map(sub{
    return{
        order_id =>$_->{name},
        payment_id=>$_->{payment_id},
        transfer_id=>$_->{transfer_id},
        transfer_amount=>$_->{transfer_amount}


    }

})->to_array;


  $c->render(json => {

    charging_sessions => $charging_sessions,
         evuserEVSEAction => $evuserEVSEAction,
        # evse => [],
        # evehicles => [],
        customer_payout_cso_api_response => $customer_payout_cso_api_response

  });

}

1;