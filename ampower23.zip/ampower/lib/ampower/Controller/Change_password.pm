
package ampower::Controller::Change_password;
use Mojo::Base 'Mojolicious::Controller', -signatures;



sub change_pass {
        my $self = shift;

    # Retrieve username from the session
    my $new_email = $self->session('username');
    say "username:::$new_email";
    my $old_password = $self->param('oldpassword') ;
    say "old_password:::$old_password";
    my $new_password = $self->param('newpassword');
    my $confirm_password = $self->param('confirmnewpassword');

    my $dbh = $self->app->db;

    # Check if old password matches the one in the database for the given username
    my $sth = $dbh->prepare("SELECT password FROM users WHERE email = ?");

   $sth->execute($new_email);
my ($stored_password) = $sth->fetchrow_array;

    say "db password:$stored_password";
    if (defined $stored_password eq defined $old_password )
    { 
        say "helloo";
        if(defined $new_password eq defined $confirm_password) {
        # Update the password in the database
        $sth = $dbh->prepare("UPDATE users SET password = ? WHERE email = ?");
        $sth->execute($new_password, $new_email);
        say "sth:$new_password";
        print "Password updated successfully.\n";
    } else {
        print "new passwords do not match. Password not updated.\n";
    }}
else{
    print "old password wrong.\n";
}
  $self->render(template => 'myTemplates/change_password');

} 
1;