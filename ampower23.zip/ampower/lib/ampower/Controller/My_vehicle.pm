package ampower::Controller::My_vehicle;
use Mojo::Base 'Mojolicious::Controller', -signatures;




sub my_vehicle {
  my $self  = shift;

  my $mysql = $self->mysql;
  my $dbh   = $mysql->db;

  my $result1 = $dbh->query("select * from evehicles");

  my (@data_collect, $id, $row_vehicleType, $row_vehMakeName, $row_vehModel, $row_vehRegNo);

    while (my $row = $result1->hash) {
        if (ref($row) eq 'HASH') {

            $id          = $row->{vehid};
            $row_vehicleType    = $row->{vehicletype};
            $row_vehMakeName  = $row->{vehmakename};
            $row_vehModel   = $row->{vehmodel};
            $row_vehRegNo = $row->{vehregno};

            my $data1 = {
                vehid       => $id,
                vehicletype     => $row_vehicleType,
                vehmakename   => $row_vehMakeName,
                vehmodel    => $row_vehModel,
                vehregno => $row_vehRegNo
            };
            say "$data1 :data1 ";

            push @data_collect, $data1;
          say "@data_collect:datacollect"
        }
        else {
            $self->app->log->error('no data found');
        }
    }
  say "@data_collect: data collect";
    
    $self->render(template => 'myTemplates/my_vehicles', vehicles => \@data_collect);
    }



sub add_vehicle {
    my $self = shift;

    # Get user input from the form
    my $vehicleType   = $self->param('vehicletype');
    my $vehMakeName   = $self->param("vehmakename");
    my $vehModel      = $self->param('vehmodel');
    my $vehRegNo      = $self->param('vehregno');
    say "vehicletype: $vehicleType";
    say "vehMakeName: $vehMakeName";
    say "vehModel: $vehModel";
    say "vehRegNo: $vehRegNo";
    my $mysql = $self->mysql;
    my $dbh   = $mysql->db;
    # Log input data for debugging
    $self->app->log->debug("vehicleType=$vehicleType, vehMakeName=$vehMakeName, vehModel=$vehModel, vehRegNo=$vehRegNo");

    $mysql = $self->app->mysql;

    # Insert user into the database
    my $result = $dbh->query('INSERT INTO evehicles(vehicletype, vehmakename, vehmodel, vehregno) VALUES (?, ?, ?, ?)', $vehicleType, $vehMakeName, $vehModel, $vehRegNo);
    
    if ($result) {
        return $self->render(json => {success => 1, message => "Inserted successfully"});
    } else {
        return $self->render(json => {success => 0, message => "Failed to insert into database"}, status => 500);
    }
}



sub delete_vehicle {
    my $self = shift;

    # Get user ID to delete
    my $id_to_delete = $self->param('vehid');
    say "id_to_delete: $id_to_delete";
    $self->app->log->debug("Deleting vehicle with ID: $id_to_delete");

    # Log for debugging
    $self->app->log->debug("Deleting user with ID: $id_to_delete");

    # Delete user from the database
    my $mysql = $self->mysql;
    my $dbh   = $mysql->db;
    my $result = $dbh->query('DELETE FROM evehicles WHERE vehid = ?', $id_to_delete);
    say "Deleted user with ID: $id_to_delete";

if ($result) {
        return $self->render(json => {success => 1, message => "Deleted successfully"});
    } else {
        return $self->render(json => {success => 0, message => "Failed to delete from database"}, status => 500);
    }
    # Redirect back to the user list page
    $self->redirect_to('/my_vehicles');

        # $self->render(template => "myTemplates/register_form");

}





1;