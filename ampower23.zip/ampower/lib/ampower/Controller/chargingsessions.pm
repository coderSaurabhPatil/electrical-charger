package ampower::Controller::Chargingsessions;

use Mojo::Base 'Mojolicious::Controller', -signatures;

sub chargingsessions ($self) {

  

    $self->render(template => 'myTemplates/charging-sessions');

}


# Fetches EV vehicles associated with the user
sub fetchUserEVehicles ($self) {
    my $user_id = $self->param('user_id');  # Assuming user_id is passed as a parameter
    my @vehicles = fetch_user_vehicles_from_database($user_id);
    $self->render(json => \@vehicles);
}

# Handles EVSE (Electric Vehicle Supply Equipment) selection
sub evseSlctd ($self) {
    my $evse_id = $self->param('evse_id');  # Assuming evse_id is passed as a parameter
    my $selected_evse = get_evse_info($evse_id);
    $self->render(json => $selected_evse);
}

# Fetches the current balance of a customer using RazorPay API
sub fetchCustomerCurrentBalance ($self) {
    my $customer_id = $self->param('customer_id');  # Assuming customer_id is passed as a parameter
    my $current_balance = fetch_balance_from_razorpay_api($customer_id);
    $self->render(json => { balance => $current_balance });
}

# Checks if a customer has a wallet
sub checkIfCustomerHasWallet ($self) {
    my $customer_id = $self->param('customer_id');  # Assuming customer_id is passed as a parameter
    my $has_wallet = check_customer_wallet($customer_id);
    $self->render(json => { has_wallet => $has_wallet });
}

# Lists EVSE statuses
sub list_evse_statuses ($self) {
    my @evse_statuses = get_evse_statuses();
    $self->render(json => \@evse_statuses);
}

# Lists EVSE statuses and related information
sub evse_listing ($self) {
    my @evse_info = get_evse_listing();
    $self->render(json => \@evse_info);
}

# Checks the previous charging session state
sub checkPrevChargingSessionState ($self) {
    my $session_id = $self->param('session_id');  # Assuming session_id is passed as a parameter
    my $session_state = check_session_state($session_id);
    $self->render(json => { session_state => $session_state });
}

# Finalizes billing and payment transfer
sub finalizeBill_Transfer_Pymnt ($self) {
    my $session_id = $self->param('session_id');  # Assuming session_id is passed as a parameter
    my $bill_amount = calculate_session_bill($session_id);
    my $payment_status = transfer_payment($bill_amount);
    $self->render(json => { payment_status => $payment_status });
}

# Calculates ongoing charging bill
sub calculateOnGoingBill ($self) {
    my $session_id = $self->param('session_id');  # Assuming session_id is passed as a parameter
    my $bill_amount = calculate_session_bill($session_id);
    $self->render(json => { bill_amount => $bill_amount });
}

# Fetches EVSE charging information
sub fetchEVSEChargingInfo ($self) {
    my $evse_id = $self->param('evse_id');  # Assuming evse_id is passed as a parameter
    my $charging_info = get_charging_info($evse_id);
    $self->render(json => $charging_info);
}


1;
