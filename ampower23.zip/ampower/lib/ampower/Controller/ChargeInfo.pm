package ampower::Controller::ChargeInfo;
use Mojo::Base 'Mojolicious::Controller', -signatures;

sub show_charge_info ($self) {
    # Get JSON body from the request
    my $json_body = $self->req->json;

    # Check if JSON body exists
    unless ($json_body && exists $json_body->{latlong}) {
        $self->render(
            status => 400,
            json   => { error => 'Invalid JSON body or missing "latlong" parameter' }
        );
        return;
    }

    # Extract latlong from the JSON body
    my $latlong = $json_body->{latlong};
    say "latlong: $latlong";

    # Fetch user info from the chargingstation table
    my $show_charge_user = $self->mysql->db->query(
        'SELECT id, code, name, locnAddress, MobileNo FROM chargingstation WHERE mapCoords = ?', $latlong
    )->hashes->to_array;

    say "show_charge_user: $show_charge_user";

    my $id = $self->mysql->db->query(
        'SELECT id FROM chargingstation WHERE mapCoords = ? ', $latlong
    )->hash->{id};

    # Query to fetch station info
    my $station_info_query = $self->mysql->db->query(
        'SELECT t1.id AS id, t1.code AS evse_id, t1.imei AS imei, t1.chargerType, t2.Status, t1.status AS evse_status 
        FROM evse t1, chargingstation t2, evse2chargingstation_assocn t3 WHERE t1.deletedOn IS NULL AND t2.deletedOn IS NULL AND t3.deletedOn IS 
        NULL AND t1.id = t3.child_id AND t2.id = t3.parent_id AND t3.parent_id = ? AND LENGTH(t1.ccid) >= 19 ORDER BY evse_id ASC', $id
    )->hashes;

    say "Station Info Query: $station_info_query";

    # Array to store station info
    my @show_charge_stations;

    foreach my $station_info (@$station_info_query) {
        my $id = $station_info->{id};
        say "id: $id";

        my ($evse_status, $show_evse_status, $connector_status);

       my $status_notifications = $self->mysql->db->query(
    'SELECT connector_status, error_code FROM status_notifications WHERE evse = ? ORDER BY received_at DESC LIMIT 1', $id
)->hash // {};

say "Status Notifications: $status_notifications";

# Fetch additional data from heartbeat_notifications table based on evse_id
my $heartbeat_notifications = $self->mysql->db->query(
    'SELECT error_code FROM heartbeat_notifications WHERE evse = ? AND received_at >= DATE_SUB(now(), INTERVAL 2 MINUTE) ORDER BY received_at DESC LIMIT 1', $id
)->hash // {};

say "Heartbeat Notification: $heartbeat_notifications";

# Fetch additional data from status_notifications table based on evse_id
my $status_notifications2 = $self->mysql->db->query(
    'SELECT connector_status  as connector_status2, error_code as error_code2 FROM status_notifications WHERE evse = ? AND received_at > DATE_SUB(now(), INTERVAL 2 MINUTE) ORDER BY received_at DESC LIMIT 1', $id
)->hash // {};

say "status_notification: $status_notifications2";
        # Check if $heartbeat_notifications exists and contains a value
my $heartbeat_error_code = defined $heartbeat_notifications ? $heartbeat_notifications->{error_code} : undef;

my( $evsestatus, $connectors );
# Process data according to your logic
if (
    
    defined $heartbeat_error_code &&    # Check if $heartbeat_error_code is defined
    $heartbeat_error_code == 0 &&       # Check if $heartbeat_error_code is 0
    (
        $status_notifications2->{connector_status2} =~ /^Available$/ ||
        $status_notifications2->{connector_status2} =~ /^EvConnected$/ ||
        $status_notifications2->{connector_status2} =~ /^EVSEReady$/
    )
) {
    ($show_evse_status, $connector_status) = ("start", "Available");
}
        
        
        elsif (($status_notifications->{connector_status} =~ /^Occupied$/ || $status_notifications2->{connector_status2} =~ /^Occupied$/) && ($evse_status =~ /^Updated$|^Started$/)) {
            ($show_evse_status, $connector_status) = ("", "Busy");
        }
        
        else {
            ($show_evse_status, $connector_status) = ("", "Unavailable");
            if ($heartbeat_notifications->{error_code} == 1) {
                $show_evse_status .= "(Mains Power Failure)";
            }
            elsif ($heartbeat_notifications->{error_code} == 2) {
                $show_evse_status .= "(Emergency Stopped Pressed)";
            }
        }

        my ($perMinChrgs, $perKWhChrgs, $minConnChrgs);

        # Check if tariff info exists and set default values if not
        my $prep_rates_query = $self->mysql->db->query(
            'select perMinChrgs, perKWhChrgs, minConnChrgs FROM tariffInfo WHERE evse_id=? AND deletedon IS NULL', $id
        )->hash;

        if ($prep_rates_query) {
            $perMinChrgs = $prep_rates_query->{perMinChrgs} || '-';
            $perKWhChrgs = $prep_rates_query->{perKWhChrgs} || '-';
            $minConnChrgs = $prep_rates_query->{minConnChrgs} || '-';
        }
        else {
            $perMinChrgs = '-';
            $perKWhChrgs = '-';
            $minConnChrgs = '-';
        }

        # Push each station info along with additional data into the array
        push @show_charge_stations, {
            station_id        => $station_info->{id},
            evse_id           => $station_info->{evse_id},
            imei              => $station_info->{imei},
            chargerType       => $station_info->{chargerType},
            evse_status       => $station_info->{evse_status},
            %$status_notifications,    # Merge additional data into the hash
            %$heartbeat_notifications,
            %$status_notifications2,   # Merge heartbeat notification data into the hash
            show_evse_status  => $show_evse_status,  # Add show_evse_status to the hash
            connector_status  => $connector_status,   # Add connector_status to the hash
            perMinChrgs       => $perMinChrgs,       # Tariff information for per minute charges
            perKWhChrgs       => $perKWhChrgs,      # Tariff information for per KWH charges
            minConnChrgs      => $minConnChrgs       # Minimum connection time for charging
        };
    }

    # Render the response
    $self->render(json => {
        user_info    => $show_charge_user,
        station_info => \@show_charge_stations
    });
}

1;

