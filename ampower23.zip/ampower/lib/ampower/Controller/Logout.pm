
package MyApp::Controller::Logout;

use Mojo::Base 'Mojolicious::Controller';

sub logout {

    my $self = shift;

    # Remove session and direct to logout page
    $self->session(expires => 1);  #Kill the Session
    $self->render(template => "myTemplates/login");

}
1;