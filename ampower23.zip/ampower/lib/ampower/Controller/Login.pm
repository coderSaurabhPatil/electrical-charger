
package ampower::Controller::Login;
use Mojo::Base 'Mojolicious::Controller', -signatures;


sub login {

my $self = shift;
$self->render(template => 'myTemplates/login');
}


sub validUserCheck {
    my $c = shift;

    my $new_email = $c->param('u_name');
    my $new_password = $c->param('password1');

    my $mysql = $c->app->mysql;
    $mysql->db->query(
        'SELECT id,email, password FROM users WHERE email = ?',
        $new_email,
        sub {
            my ($db, $err, $results) = @_;
            if ($err) {
                $c->app->log->error("Database error: $err");
                $c->render(text => 'Database error occurred', status => 500);
                return;
            }

            if (my $row = $results->hash) {
                my ($db_id, $db_email, $db_password) = @{$row}{qw(id email password)};
                
                if ($db_id && $db_email && $db_password && $db_password eq $new_password) {
                    $c->session(user_id => $db_id); # Corrected to use $db_id
                    $c->session(is_auth => 1);             
                    $c->session(username => $new_email);        
                    $c->session(expiration => 600);        
                    $c->render(template => 'myTemplates/index');
                } else {
                    $c->stash(message => 'Invalid email or password');
                    $c->render(template => 'myTemplates/login');
                }
            } else {
                $c->stash(message => 'User not found');
                $c->render(template => 'myTemplates/login');
            }
        }
    );
}

sub logout {
    my $c = shift;
    $c->session(expiration => 1);
    $c->redirect_to('login');
}

sub already_logged_in {
    my $c = shift;
    return 1 if $c->session('is_auth');
    return 0;
}


1;

