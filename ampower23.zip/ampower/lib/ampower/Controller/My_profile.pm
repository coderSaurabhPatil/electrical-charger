package ampower::Controller::My_profile;
use Mojo::Base 'Mojolicious::Controller', -signatures;

sub my_profile1 {
    my $c = shift;
    say "hi";
    my $new_email = $c->session('username');
    say "username:::$new_email";

    my $dbh = $c->app->db;
    my $sql = "select fname,lname,email,mobile,username,pincode from users where email = ?";
    my $sth = $dbh->prepare($sql);
    $sth->execute($new_email);  

    my (@data_collect, $uname, $fname, $lname, $email, $mobile, $pincode);
    say "helloo";
    while (my $row = $sth->fetchrow_hashref) {  
        say "hiii$row";
        $uname   = $row->{username};  
        $fname   = $row->{fname};
        $lname   = $row->{lname};
        $email   = $row->{email};
        $mobile  = $row->{mobile};
        $pincode = $row->{pincode};

        my $data1 = {
            uname   => $uname,
            fname   => $fname,
            lname   => $lname,
            email   => $email,
            mobile  => $mobile,
            pincode => $pincode
        };
        say "$data1 :data1 ";
        push @data_collect, $data1;
        say "data1 : $data1";
    }

    $c->render(template => "myTemplates/my_profile", userdata => \@data_collect, error_message => "");
}

1;
