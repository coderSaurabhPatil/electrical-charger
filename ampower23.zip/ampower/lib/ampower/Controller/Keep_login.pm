package MyApp::Controller::Keep_login;

use Mojo::Base 'Mojolicious::Controller';
# use MyApp::Controller::Auth;


sub check_logged_in {
    my $c = shift;

    # Check if the user is logged in
    unless ($c->session('keep_logged_in')) {
        # If not logged in, redirect to the login page
        $c->redirect_to('/dashboard');
        return 0; # Return false indicating user is not logged in
    }

    return 1; # Return true indicating user is logged in
}


# Route for the dashboard
sub dashboard {
    my $c = shift;

    # Check if the user is logged in
    return unless MyApp::Controller::Keep_login::check_logged_in($c);

    # Render the dashboard template
    $c->render(template => 'myTemplates/homepage');
}






1;
