package ampower::Controller::ChargingDetails2;
use Mojo::Base 'Mojolicious::Controller', -signatures;
use Mojo::Log;


sub show_charging_details ($self) {
    my $log = Mojo::Log->new;

    
    my $station_id = $self->session('station_id');

     # Fetch user ID from session
 my $user_id = $self->session('user_id');
 say "user_id: $user_id";




    # Query to fetch station info
    my $station_info_query = $self->mysql->db->query(
        'SELECT t1.id AS id, t1.code AS evse_id, t1.imei AS imei, t1.chargerType, t2.Status, t1.status AS evse_status FROM evse t1, chargingstation t2, evse2chargingstation_assocn t3 WHERE t1.deletedOn IS NULL AND t2.deletedOn IS NULL AND t3.deletedOn IS NULL  AND LENGTH(t1.ccid) >= 19 AND t1.id = ? ORDER BY evse_id ASC',
        $station_id
    )->hash;

    unless ($station_info_query && ref($station_info_query) eq 'HASH') {
        $log->error("Station info query did not return a valid hash reference.");
        return $self->render(json => { error => 'Failed to retrieve station information.' }, status => 500);
    }

    $log->info("Station info query: " . Mojo::Util::dumper($station_info_query));

    # Query to fetch tariff rates
    my $prep_rates_query = $self->mysql->db->query(
        'SELECT perMinChrgs, perKWhChrgs, minConnChrgs FROM tariffInfo WHERE  evse_id=? AND deletedon IS NULL',
        $station_info_query->{id}
    )->hash;

    $log->info("Prep rates query: " . Mojo::Util::dumper($prep_rates_query));

    # Extract charging rates or set defaults
    my ($perMinChrgs, $perKWhChrgs, $minConnChrgs) = ('-', '-', '-');
    if ($prep_rates_query && ref($prep_rates_query) eq 'HASH') {
        $perMinChrgs = $prep_rates_query->{perMinChrgs} || '-';
        $perKWhChrgs = $prep_rates_query->{perKWhChrgs} || '-';
        $minConnChrgs = $prep_rates_query->{minConnChrgs} || '-';
    }

    $log->info("Per minute charges: $perMinChrgs");
    $log->info("Per KWh charges: $perKWhChrgs");
    $log->info("Minimum connection charges: $minConnChrgs");

    # Fetch child IDs from association table
    my $child_ids = $self->mysql->db->query('SELECT child_id FROM evse2chargingstation_assocn WHERE parent_id = ? AND deletedon IS NULL', $user_id)->hashes->map(sub { $_->{child_id} })->to_array;

    # Declare an array to store both station and vehicle data
    my @combined_data;

    # Construct the response data for station
    my $station_data = {
        station_id     => $station_info_query->{id},
        evse_id        => $station_info_query->{evse_id},
        imei           => $station_info_query->{imei},
        chargerType    => $station_info_query->{chargerType},
        evse_status    => $station_info_query->{evse_status},
        perMinChrgs    => $perMinChrgs,
        perKWhChrgs    => $perKWhChrgs,
        minConnChrgs   => $minConnChrgs
    };

    $log->info("Station data: " . Mojo::Util::dumper($station_data));

    # Push station data into combined array
    push @combined_data, $station_data;

    # Fetch data for each child ID
    foreach my $child_id (@$child_ids) {
        # Fetch vehicle data excluding rows with deletedon not null
        my $vehicle_data = $self->mysql->db->query('SELECT * FROM evehicles WHERE vehid = ? AND deletedon IS NULL', $child_id)->hash;
        if ($vehicle_data) {
            # Fetch vehicle make using vehMakeId
            my $vehMakeId = $vehicle_data->{vehMakeId};
            my $vehicleMake = $self->mysql->db->query('SELECT vehicleMake FROM vehicleMake WHERE vehMakeId = ?', $vehMakeId)->hash->{vehicleMake};
            $vehicle_data->{vehicleMake} = $vehicleMake;

            # Fetch vehModel and vehRegNo
            my $vehModel = $vehicle_data->{vehModel};
            say "$vehModel vehmodel";
            my $vehRegNo = $vehicle_data->{vehRegNo};
            
            # Add vehModel and vehRegNo to the vehicle data
            $vehicle_data->{vehModel} = $vehModel;
            $vehicle_data->{vehRegNo} = $vehRegNo;

            # Push vehicle data into combined array
            push @combined_data, $vehicle_data;
        }
    }

    # Render the response
    $self->render(json => { combined_data => \@combined_data });
}


1;
