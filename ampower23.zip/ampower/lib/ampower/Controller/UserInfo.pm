package ampower::Controller::UserInfo;

use Mojo::Base 'Mojolicious::Controller', -signatures;

# Mojolicious Controller

# Mojolicious Controller

sub user_info {
    my $c = shift;

    # Retrieve user ID from the session
    my $user_id = $c->session('username');

    # Fetch user information from the database based on the user ID
    my $user_info = $c->mysql->db->query('SELECT fname, email FROM users WHERE email = ?', $user_id)->hash;

    # Render user information as JSON
    $c->render(json => $user_info);
}
1;
