package ampower::Controller::Map;

use Mojo::Base 'Mojolicious::Controller', -signatures;

sub stations {
    my $c = shift;

    # Fetch latitude, longitude coordinates and address details from the chargingstation table
    my $charging_stations = $c->mysql->db->query('SELECT id, code, mapCoords, locnAddress FROM chargingstation')->hashes->map(sub {
        # Split mapCoords into latitude and longitude
        my ($latitude, $longitude) = split /,/, $_->{mapCoords};
        say  "id $_->{id} ";
        return {

             id => $_->{id},
             code => $_->{code},
             latitude => $latitude,
             longitude => $longitude,
             address => $_->{locnAddress}
           
        };
    })->to_array;       

    # Log the fetched charging station data
    $c->app->log->info("Fetched charging stations: " . scalar(@$charging_stations));

    for my $station (@$charging_stations) {
        $c->app->log->info("Station: stationId: $station->{id}, code: $station->{code}, Latitude: $station->`{latitude}, Longitude: $station->{longitude}, Address: $station->{address},");
    }

    $c->render(json => $charging_stations);

}

1;
