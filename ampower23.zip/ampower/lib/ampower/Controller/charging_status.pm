package ampower::Controller::ChargingStatus;

use Mojo::Base 'Mojolicious::Controller', -signatures;

sub status ($self) {
    # Retrieve latitude and longitude from the request parameters
    my $latitude = $self->param('latitude');
    my $longitude = $self->param('longitude');

    my $latlong = "$latitude,$longitude";

    say "Latitude: $latitude";
    say "Longitude: $longitude";
    say "Coordinates: $latlong";

    # Pass $latlong variable to the template
    $self->render(template => 'myTemplates/charging-status', latlong => $latlong);
}

1;
