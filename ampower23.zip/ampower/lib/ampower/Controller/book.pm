package ampower::Controller::Book;
use Mojo::Base 'Mojolicious::Controller';
use Geo::Distance;
use Data::Dumper;
use JSON::MaybeXS;
use Mojo::JSON;

sub book {
    my $c = shift;

    my $evse_id = $c->param('evse_id');
    my $charger_type = $c->param('charger_type') // '';

    $c->render(template => "myTemplates/book", evse_id => $evse_id, charger_type => $charger_type);
}

sub bookev {
    my $c = shift;

    # Query the database to fetch names and map coordinates of all charging stations
    my $result = $c->mysql->db->query('SELECT name, mapCoords FROM chargingstation');

    # Iterate over the results and print the name and map coordinates
    while (my $row = $result->hash) {
        my $name = $row->{name};
        my $mapCoords = $row->{mapCoords};
        print "Name: $name, Map Coordinates: $mapCoords\n";
    }

    $c->render(template => "myTemplates/bookev");
}





sub search_bar {
    my $c = shift;

    # Get the search query from the request parameters
    my $search_query = $c->param('search_query');

    # Check if the search query has at least three characters
    if (length($search_query) < 3) {
        return $c->render(json => { error => "Search query must be at least three characters long" }, status => 400);
    }

    # Add wildcard to match the first three letters of the search query
    my $query = substr($search_query, 0, 3) . '%';

    # Execute the SQL statement with a bind parameter for the search query
    my $promise = $c->mysql->db->query_p(
        'SELECT id, name, mapCoords FROM chargingstation WHERE name LIKE ? LIMIT 5', 
        $query
    );

    $promise->then(sub {
        my $results = shift;

        my @stations;

        # Iterate over the search results to calculate distance
        while (my $row = $results->hash) {
            # Push station data to the stations array
            push @stations, {
                id => $row->{id},
                name => $row->{name},
                mapCoords => $row->{mapCoords},
            };
        }

        # Return search results as JSON
        $c->render(json => \@stations);
    })->catch(sub {
        my $err = shift;
        $c->render(json => { error => $err }, status => 500);
    });
}



sub ev_display {
    my $c = shift;

      my $latitude = $c->param('latitude');
    my $longitude = $c->param('longitude');

    # Retrieve latitude, longitude, and charger type from the request parameters
    my $mapCoords = $c->param('mapCoords');
    my $charger_type = $c->param('charger_type');

    # Print the received data to the console
    print "mapCoords: $mapCoords\n";
    print "Charger Type: $charger_type\n";

    # Query the database to fetch names and map coordinates of charging stations
   my $result = $c->mysql->db->query('SELECT id, name, mapCoords FROM chargingstation WHERE mapCoords = ?', $mapCoords);

   print ("Querying Database...", $result);


    my @stations; # Declare @stations here

    # Iterate over the charging stations to calculate distances and store charger data
    while (my $row = $result->hash) {
        my $station_id = $row->{id};
        my $station_name = $row->{name};
        my $mapCoords = $row->{mapCoords};

        # Extract latitude and longitude from mapCoords
        my ($stationLat, $stationLong) = split /,/, $mapCoords;

        # Calculate the distance between user's location and station's location
        my $distance = Geo::Distance->new()->distance('kilometer', $longitude, $latitude, $stationLong, $stationLat);


        # Push station data along with distance to the stations array
        push @stations, {
            id => $station_id,
            name => $station_name,
            distance => $distance,
            latitude => $stationLat,  # Assign latitude value to station object
            longitude => $stationLong,  # Assign longitude value to station object
            charger_type => $charger_type  # Assign charger type value to station object
        };
    }

    # Sort the stations array based on distance in ascending order
    @stations = sort { $a->{distance} <=> $b->{distance} } @stations;

    # Fetch and append charger info for each station (similar to your existing code)
       # Fetch and append charger info for each station
    foreach my $station (@stations) {
        my $station_id = $station->{id};

        # Query to fetch station info
        my $station_info_query = $c->mysql->db->query(
            'SELECT t1.id AS id, t1.code AS evse_id, t1.imei AS imei, t1.chargerType, t2.Status, t1.status AS evse_status 
            FROM evse t1, chargingstation t2, evse2chargingstation_assocn t3 
            WHERE t1.deletedOn IS NULL AND t2.deletedOn IS NULL AND t3.deletedOn IS NULL 
            AND t1.id = t3.child_id AND t2.id = t3.parent_id AND t3.parent_id = ? AND LENGTH(t1.ccid) >= 19 
            ORDER BY evse_id ASC ', $station_id
        )->hashes;

        # Append charger info to the station data
        $station->{chargers} = $station_info_query;
    }

    # Render JSON response with sorted station data
    $c->render(json => \@stations);
}


sub search {
    my $c = shift;

    # Get the user's live location from the request parameters
    my $latitude = $c->param('latitude');
    my $longitude = $c->param('longitude');

    # Query the database to fetch names and map coordinates of all charging stations
    my $result = $c->mysql->db->query('SELECT id,name, mapCoords FROM chargingstation');

    my @chargers;
    # Iterate over the results to calculate distances and store charger data
    while (my $row = $result->hash) {
        my $name = $row->{name};
        my $mapCoords = $row->{mapCoords};
        
        # Extract latitude and longitude from mapCoords
        my ($chargerLat, $chargerLong) = split /,/, $mapCoords;

        # Check if latitude and longitude values are valid
        if ($latitude && $longitude && $chargerLat && $chargerLong) {
            # Calculate the distance between user's location and charger's location
            my $distance = Geo::Distance->new()->distance( 'kilometer', $longitude, $latitude, $chargerLong, $chargerLat );

            # Push charger data along with distance to the chargers array
            push @chargers, { name => $name, distance => $distance };
        } else {
            # Handle invalid coordinates
            warn "Invalid coordinates for charger $name";
        }
    }

    # Sort the chargers array based on distance in ascending order
    @chargers = sort { $a->{distance} <=> $b->{distance} } @chargers;
    foreach my $chargers (@chargers) {
        my $station_id = $chargers->{id};

        # Query to fetch station info
        my $station_info_query = $c->mysql->db->query(
            'SELECT t1.id AS id, t1.code AS evse_id, t1.imei AS imei, t1.chargerType, t2.Status, t1.status AS evse_status 
            FROM evse t1, chargingstation t2, evse2chargingstation_assocn t3 
            WHERE t1.deletedOn IS NULL AND t2.deletedOn IS NULL AND t3.deletedOn IS NULL 
            AND t1.id = t3.child_id AND t2.id = t3.parent_id AND t3.parent_id = ? AND LENGTH(t1.ccid) >= 19 
            ORDER BY evse_id ASC ', $station_id
        )->hashes;

        # Append charger info to the station data
        $chargers->{chargers} = $station_info_query;
    }

    # Render JSON response with sorted charger data
    $c->render(json => \@chargers);
}


sub booking {

    my  $c = shift;

    my $user_id = $c->param('user_id');
    my $charging_station = $c->param('charging_station_id');
    my $start_time = $c->param('start_time');
    my $end_time = $c->param('end_time');



$c->render(text =>"Booking submitted successfully");

}

sub add_slot {
    my $c = shift;

    my  $date = $c->param('date');
    my $start_time = $c->param('start_time');
    my $end_time = $c->param('end_time');
    my $charging_station_id =  $c->param('charging_station_id');

    # Insert new slot into the database
    my $db = $c->app->db;
    $db->insert('reservation_slots', {
        date => $date,
        start_time => $start_time,
        end_time => $end_time,
        charging_station_id => $charging_station_id
    });
    
    $c->render(text => "Reservation slot added successfully!");




}


sub  available_slots
 {
    my $c = shift;

   # Retrieve query parameters from the request
    my $selectedDate = $c->param('selectedDate');
 
    my $evseId = $c->param('evse_id');
    my $user_id = $c->session('user_id');
    my $email = $c->session('username');


    my $result = $c->mysql->db->query('SELECT * FROM reservation_slots WHERE date = ? AND charging_station_id = ?', $selectedDate, $evseId)->hashes;

    $c->render(json =>$result);
}


sub SubmitBookingFormData {
    my $c = shift;

    # Retrieve query parameters from the request
    my $selectedDate = $c->param('date');
    my $startTime = $c->param('start_time');
    my $endTime = $c->param('end_time');
    my $evseId = $c->param('evse_id');
    my $chargerType = $c->param('charger_type');

    my $user_id = $c->session('user_id');
    my $email = $c->session('username');

  
    # If the slot is not already booked, proceed to book it
    my $res = $c->mysql->db->query('INSERT INTO reservation_slots SET date = ?, start_time = ?, end_time = ?, charging_station_id = ?, user_id = ?, user_email = ?', $selectedDate, $startTime, $endTime, $evseId, $user_id, $email);


}






1;