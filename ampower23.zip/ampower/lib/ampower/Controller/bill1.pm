package ampower::Controller::Bill1;
use Mojo::Base 'Mojolicious::Controller';

sub bill {

  my  $c -> shift;

   $c-> render(template => "myTemplates/bill");
}

1;