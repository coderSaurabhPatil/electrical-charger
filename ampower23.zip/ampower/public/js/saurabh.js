//-----------------------------------------------------------------------------------index
// Function to handle button click
function openGoogleMaps(latitude,longitude) {
    var googleMapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
    window.open(googleMapsUrl, '_blank');
}
// Fetch user information from the server
fetch('/user_info')
    .then(response => response.json())
    .then(data => {
        // Update HTML content with fetched user information
        document.getElementById('username').textContent = data.fname;
        document.getElementById('email').textContent = data.email;
    })
    .catch(error => console.error('Error fetching user information:', error));

$(document).ready(function() {
    var mymap = L.map('map').setView([19.114074, 72.880616], 13); // Default coordinates near Mumbai

    // Add tile layer
    L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibGVubnlmZXJuYW5kZXMiLCJhIjoiY2tsbnExbzZxMDZkajJwa2FsNDY5bjNxcCJ9.299zdWoOQ99Xb1aojlFoSA', 
    {
        maxZoom: 18,
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, ' +
        'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        id: 'mapbox/streets-v11',
        tileSize: 512,
        zoomOffset: -1,
    }).addTo(mymap);

// Create the live location marker with the provided base64 encoded image as icon and increased size
var liveLocationIcon = L.icon({
    iconUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAADSElEQVR4nO2XT0gUURzHfwZJf6xLUkEFaQl2K4SKfLNjhXYsIqKLdSghugWVIMIGBUGmM7u9t+KxDkJ1KdcoIfLfUSIkOpR46GZIaWXue2L+4r1dzNadmd3Z7e0S84UvDMP8fu/znXnvzQxAoECBAv03QhMqkUALEniGBnxAAnPKyWN57hIehy1QasJG2IgG3EQCP9AA9PB3JBDGOtgApSA0YBcSeJMFeLrH0YCq4sITqEYDPvuAT5rAVNFC4BHYhAa89w3/J8Q7NKFCfwACd/KGN5ZD3NILb8J2NGDeBegpEjDV4pauhwY0oM8lxE88BNv0BSBwxQW+1aWuzSXEZX0BDHjhdOezqI071D7XQ5+EmHSAMD1rQ3DUoXZCZ4DM8z+L3SS1e2VcB6BLSGDGd4CDsNkhwBedT2A0I0Q9NGRRe8whwKge+iREuwNEn2ctgX6H2nad74GdSGDRYTG25RycwKLsqS2Agkl+Hjvt6XG125hQoSynjfOdR9lLK7wKYEBTwT4lDGjSHiAVYrAA8KNFgVcB6oHkHYB4v/z+bQi3ue0N319UeBUgBDVIgPsIINCEWigFoQG3S/4fwE14GNY7fuBl9if5nwDFVBgfl0cWYnWWoC22oJ0v483DSyFveHnNQPz8kKyxBG2RPWQvLdAWZ/ssHmu1OBu1OF2wBcOVHu8wPAOM3wv9VWMLhqoXpyM2ZzfkGAWFDmN4TRenZyR0+sDppt8snDm31RF+9mwlstku1x62NKcjFmenEbEsL/hIIrLH5mzYc8AVfvT2Gi6Za1ZPHbMMn4xdzbqPnfRgVyJW7Qs+mohWWYJN5Tig8hhrWhVAnvPTy+Z0ujNB9+YcQM1JPwMKhvfnIjh9YccyvDyW5/z2szgd8hGAzfsdUPrBZBjFiXW40FiODz+2++5jq6fA5nMOIFPnNahgOBBvVs63jyXo69wDJLp3+10DBTWn03IzyTnAihCvigg/YvPuGshHci+2ODtViCmV9ZThdCjC6cm83wPpivJorcXpdRWGU1E4YMblni97yzFAh3qwZ21ExA7Ygl20BO2wOetNva0n5NqxOP1qc/ZLWh6n1tOEuoazXluwu6na/bKXFuhAgQIFgkLrN9Kiq1jlgF/UAAAAAElFTkSuQmCC',
    iconSize: [60, 60], // Adjust the size of the icon as needed (increased from the original size)
    iconAnchor: [30, 60], // Adjust the anchor point of the icon if needed
});

// Create the live location marker
var liveLocationMarker = L.marker([0, 0]).addTo(mymap);

    // Update the live location marker
    function updateLiveLocation(location) {
        var latlng = [location.coords.latitude,location.coords.longitude];
        liveLocationMarker.setLatLng(latlng).update();
        mymap.setView(latlng);
        
       
    }

    // Error handler for geolocation
    function errorHandler(error) {
        console.error('Error getting location:', error);
    }

    // Options for geolocation
    var options = {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
    };

    // Retrieve live location periodically
    function getLiveLocation() {
        navigator.geolocation.getCurrentPosition(updateLiveLocation, errorHandler, options);
    }

    // Call getLiveLocation initially and then every 5 seconds
    getLiveLocation();
    setInterval(getLiveLocation, 5000);
    // Fetch station data from the server
    fetch('/stations')
        .then(response => response.json())
        .then(data => {
            // Iterate over each station
            data.forEach(station => {
                // Extract latitude and longitude
                var latitude = station.latitude;
                var longitude = station.longitude;
                var address = station.address;
                var id = station.id;
                var code = station.code;

                 var liveLocationIcon = L.icon({
    iconUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAADSElEQVR4nO2XT0gUURzHfwZJf6xLUkEFaQl2K4SKfLNjhXYsIqKLdSghugWVIMIGBUGmM7u9t+KxDkJ1KdcoIfLfUSIkOpR46GZIaWXue2L+4r1dzNadmd3Z7e0S84UvDMP8fu/znXnvzQxAoECBAv03QhMqkUALEniGBnxAAnPKyWN57hIehy1QasJG2IgG3EQCP9AA9PB3JBDGOtgApSA0YBcSeJMFeLrH0YCq4sITqEYDPvuAT5rAVNFC4BHYhAa89w3/J8Q7NKFCfwACd/KGN5ZD3NILb8J2NGDeBegpEjDV4pauhwY0oM8lxE88BNv0BSBwxQW+1aWuzSXEZX0BDHjhdOezqI071D7XQ5+EmHSAMD1rQ3DUoXZCZ4DM8z+L3SS1e2VcB6BLSGDGd4CDsNkhwBedT2A0I0Q9NGRRe8whwKge+iREuwNEn2ctgX6H2nad74GdSGDRYTG25RycwKLsqS2Agkl+Hjvt6XG125hQoSynjfOdR9lLK7wKYEBTwT4lDGjSHiAVYrAA8KNFgVcB6oHkHYB4v/z+bQi3ue0N319UeBUgBDVIgPsIINCEWigFoQG3S/4fwE14GNY7fuBl9if5nwDFVBgfl0cWYnWWoC22oJ0v483DSyFveHnNQPz8kKyxBG2RPWQvLdAWZ/ssHmu1OBu1OF2wBcOVHu8wPAOM3wv9VWMLhqoXpyM2ZzfkGAWFDmN4TRenZyR0+sDppt8snDm31RF+9mwlstku1x62NKcjFmenEbEsL/hIIrLH5mzYc8AVfvT2Gi6Za1ZPHbMMn4xdzbqPnfRgVyJW7Qs+mohWWYJN5Tig8hhrWhVAnvPTy+Z0ujNB9+YcQM1JPwMKhvfnIjh9YccyvDyW5/z2szgd8hGAzfsdUPrBZBjFiXW40FiODz+2++5jq6fA5nMOIFPnNahgOBBvVs63jyXo69wDJLp3+10DBTWn03IzyTnAihCvigg/YvPuGshHci+2ODtViCmV9ZThdCjC6cm83wPpivJorcXpdRWGU1E4YMblni97yzFAh3qwZ21ExA7Ygl20BO2wOetNva0n5NqxOP1qc/ZLWh6n1tOEuoazXluwu6na/bKXFuhAgQIFgkLrN9Kiq1jlgF/UAAAAAElFTkSuQmCC',
    iconSize: [60, 60], // Adjust the size of the icon as needed (increased from the original size)
    iconAnchor: [30, 60], // Adjust the anchor point of the icon if needed
});

                // Create a marker for each station
                var marker = L.marker([latitude,longitude], { icon: liveLocationIcon }).addTo(mymap);

               
                var url = `/charging_status?latitude=${latitude}&longitude=${longitude}`;

                // Create a red-colored button inside the popup
            var buttonHtml = '<button style="background-color: green; color: white;" onclick="openGoogleMaps(' + latitude + ', ' + longitude + ')">Show on Google Maps</button>';
                // Add a popup to the marker with the button
                marker.bindPopup(`<a href="${url}"><b>STATION-${id},${code}</b></a><br />${address}<br>${buttonHtml}`, { className: 'custom-popup' });


                

                // Add the marker to the map
                marker.addTo(mymap);
            });
        })
        .catch(error => console.error('Error fetching data:', error));
        
});


//--------------------------------------------------------------------------------------------------------------------------------------------------------------------charging status 

// Add an event listener for when the DOM content is fully loaded
document.addEventListener('DOMContentLoaded', function() {

    // Variable to store the interval ID for later reference
    let intervalId;

    // Function to fetch data from the server and update the table
    const fetchDataAndUpdateTable = () => {
        
        // Dummy value for demonstration purposes (to be replaced with actual data)
        const latlong = "<%= $latlong %>";

        // Define the data object containing the latitude and longitude
        const requestData = {
            latlong: latlong
        };

        // Construct the fetch options for the POST request
        const fetchOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        };

        // Mapping of status codes to image filenames and button availability
        const statusImageMap = {
            'Available': { image: 'available.svg', button: true },
            'EvConnected': { image: 'EvConnected.svg', button: true },
            'EVSEReady': { image: 'available.svg', button: true },
            'charging': { image: 'charging.svg', button: true },
            'Unavailable': { image: 'unavailable.svg', button: false },
            'busy': { image: 'busy.svg', button: true }
            // Add other status codes as needed
        };

        // Fetch data from the server's /charge_info endpoint
        fetch('/charge_info', fetchOptions)
            .then(response => response.json()) // Parse the JSON response
            .then(data => {

                 console.log(data);
                // Handle user information if available
                if (data.user_info) {
                    const userChargeInfo = data.user_info[0];
                    // Update HTML content with user charge information
                    document.querySelector('.list-unstyled li:nth-child(1)').innerHTML = `<b>Code:</b> ${userChargeInfo.code}`;
                    document.querySelector('.list-unstyled li:nth-child(2)').innerHTML = `<b>Name:</b> ${userChargeInfo.name}`;
                    document.querySelector('.list-unstyled li:nth-child(3)').innerHTML = `<b>Address:</b> ${userChargeInfo.locnAddress}`;
                    document.querySelector('.list-unstyled li:nth-child(4)').innerHTML = `<b>Contact:</b> ${userChargeInfo.MobileNo}`;
                }

                 if (data.station_info) {
                // Handle station info data
                const stationChargeInfo = data.station_info;
                const tableBody = document.querySelector('.table-responsive-stack tbody');
                tableBody.innerHTML = ''; // Clear existing table content

                // Populate table with station information
                stationChargeInfo.forEach((charge_info, index) => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${index + 1}</td>
                        <td>${charge_info.evse_id} <br> ${charge_info.chargerType} <br>${charge_info.evse_status} </td>
                        <td> Parking : Rs. -${charge_info.perMinChrgs}
                            <br>
                            KWh. Rs. -${charge_info.perKWhChrgs}
                            <br>
                            Minute Rs. -${charge_info.minConnChrgs}
                            </td>
                        
                         <td>
            <img src="images/${statusImageMap[charge_info.connector_status]?.image || 'default.svg'}" 
                alt="${charge_info.connector_status}" width="130">
            ${statusImageMap[charge_info.connector_status]?.button ? 
                `<br><button onclick="redirectToNewURL('${latlong}')", class="btn btn-secondary mt-3 px-5" data-bs-toggle="modal" data-bs-target="#available">Available</button>` : ''}
        </td>
  

                    `;
                    tableBody.appendChild(row);
                });
            }
        })
        .catch(error => console.error('Error fetching data:', error));

    }
    // Call the function initially to fetch and update the data
    fetchDataAndUpdateTable();

    // Set up an interval to fetch and update the data every 2 minutes
    intervalId = setInterval(fetchDataAndUpdateTable, 0.5 * 60 * 1000); // 2 minutes in milliseconds

    // Add an event listener to clear the interval when leaving the page
    window.addEventListener('beforeunload', function() {
        clearInterval(intervalId); // Clear the interval when leaving the page
    });

    // Add an event listener to set up a new interval when returning to the page
    window.addEventListener('focus', function() {
        // Set up a new interval to fetch and update the data every 1 minute
        intervalId = setInterval(fetchDataAndUpdateTable, 1 * 60 * 1000); // 1 minute in milliseconds
    });
});




    function redirectToNewURL(latlong) {
        // Construct the URL with the latlong parameter
        const urlWithLatLong = `/charging_details?latlong=${latlong}`;
        // Redirect to the new URL
        window.location.href = urlWithLatLong;
    }

    //-------------------------------------------------------------------------------------------------------------------------------------






    
    // Function to handle getting the user's location and sending it to the server
    function getLocationAndSearch() {
        if (navigator.geolocation) {
            // Request the user's location
            navigator.geolocation.getCurrentPosition(sendLocationToServer);
        } else {
            alert("Geolocation is not supported by this browser.");
        }
    }

    // Function to send location data to the server and initiate the search
    function sendLocationToServer(position) {
        // Extract latitude and longitude from the position object
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;

        // Create a URL-encoded string with the latitude and longitude
        var params = "latitude=" + encodeURIComponent(latitude) + "&longitude=" + encodeURIComponent(longitude);

        // Define the URL of the search endpoint
        var searchUrl = "/search?" + params;

        // Use fetch to send a GET request to the search endpoint
        fetch(searchUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error("Network response was not ok");
                }
                return response.json();
            })
            .then(data => {
                // Process the response data
                console.log(data);
                // Update the charger list with the received data
                updateChargerList(data);
            })
            .catch(error => {
                console.error("There was a problem with the fetch operation:", error);
            });
    }

    // Function to handle booking a charging station
    function bookStation(event, latitude, longitude) {
        event.preventDefault(); // Prevent default link behavior
        var url = `/charging_status?latitude=${latitude}&longitude=${longitude}`;
        window.open(url, "_blank"); // Open link in a new tab
    }

    // Function to update the charger list based on the received data
    function updateChargerList(data) {
        // Get the charger list container
        var chargerList = document.getElementById("charger-list");

        // Clear the existing charger list
        chargerList.innerHTML = "";

        // Iterate over the received data and add charger entries to the list
        data.forEach(station => {
            // Create a new station item element
            var stationItem = document.createElement("div");
            stationItem.classList.add("station-item");

            // Create elements for station name, distance, and chargers
            var stationName = document.createElement("div");
            stationName.classList.add("station-name");
            stationName.textContent = station.name;

            var stationDistance = document.createElement("div");
            stationDistance.classList.add("station-distance");
            stationDistance.textContent = (station.distance / 1000).toFixed(2) + " km away"; // Format distance

            // Create a container for chargers
            var chargersContainer = document.createElement("div");
            chargersContainer.classList.add("chargers-container");

            // Iterate over chargers for this station
            station.chargers.forEach(charger => {
                // Create a new charger item element
                var chargerItem = document.createElement("div");
                chargerItem.classList.add("charger-item");

                // Create elements for charger ID and type
                var chargerID = document.createElement("div");
                chargerID.classList.add("charger-id");
                chargerID.textContent = "Charger ID: " + charger.evse_id;

                var chargerType = document.createElement("div");
                chargerType.classList.add("charger-type");
                chargerType.textContent = "Charger Type: " + charger.chargerType;

                // Append charger ID and type to charger item
                chargerItem.appendChild(chargerID);
                chargerItem.appendChild(chargerType);

                // Append charger item to chargers container
                chargersContainer.appendChild(chargerItem);
            });

            // Create a book button for booking this station
            var bookButton = document.createElement("button");
            bookButton.classList.add("book-button");
            bookButton.textContent = "Book Station";
            bookButton.setAttribute("data-latitude", station.latitude);
            bookButton.setAttribute("data-longitude", station.longitude);
            bookButton.addEventListener("click", function(event) {
                bookStation(event, station.latitude, station.longitude);
            });

            // Append station name, distance, chargers container, and book button to station item
            stationItem.appendChild(stationName);
            stationItem.appendChild(stationDistance);
            stationItem.appendChild(chargersContainer);
            stationItem.appendChild(bookButton);

            // Append station item to charger list container
            chargerList.appendChild(stationItem);
        });
    }

    // Add an event listener to the search button to initiate the search when clicked
    document.getElementById("search-button").addEventListener("click", getLocationAndSearch);












const searchInput = document.getElementById('search-input');
const suggestionBox = document.getElementById('suggestion-box');

searchInput.addEventListener('input', function() {
const query = this.value.trim();
console.log('function is called.')

console.log('Query:', query); // Log the query

if (query.length === 0) {
    suggestionBox.innerHTML = '';
    suggestionBox.style.display = 'none';
    return;
}

  var params = "search_query=" + encodeURIComponent(query);

        // Define the URL of the search endpoint
        var url = "/search_bar?" + params;



// Send AJAX request to backend to fetch search results
fetch(url)
    .then(response => {
    console.log('Response from server:', response);
    return response.json();
})
    .then(data => {
        console.log('Response Data:', data); // Log the response data
        
        // Display search results in suggestion box
        suggestionBox.innerHTML = '';
        data.forEach(station => {
            const suggestionItem = document.createElement('div');
            suggestionItem.classList.add('suggestion-item');
            suggestionItem.textContent = station.name;
            suggestionItem.addEventListener('click', function() {
                // Handle suggestion item click event (e.g., select the suggestion)
                searchInput.value = station.name;
                suggestionBox.innerHTML = '';
                suggestionBox.style.display = 'none';
            });
            suggestionBox.appendChild(suggestionItem);
        });
        suggestionBox.style.display = 'block';
    })
    .catch(error => {
        console.error('Error fetching search results:', error);
    });
});

